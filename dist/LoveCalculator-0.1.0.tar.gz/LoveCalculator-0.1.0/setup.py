# setup.py
from setuptools import setup, find_packages

setup(
    name="LoveCalculator",
    version="0.1.0",
    description='An enchanting Python module designed to ignite the flames of affection! Dive into the realm of romance as PyLoveCalc seamlessly computes couple names and unveils the mystical percentage of love that binds them together.',
    packages=find_packages(),
    install_requires=[],
    entry_points={},
)
